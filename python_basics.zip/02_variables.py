name = 'Alice'
age = 25
print(f'My name is {name} and I am {age} years old.')
