number = 10
if number > 5:
    print('The number is greater than 5')
else:
    print('The number is 5 or less')
