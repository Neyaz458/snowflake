from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE

# Create presentation object
prs = Presentation()

# -------------------------------
# Slide 1: Title Slide
# -------------------------------
slide_layout = prs.slide_layouts[0]  # Title slide layout
slide = prs.slides.add_slide(slide_layout)

title = slide.shapes.title
subtitle = slide.placeholders[1]

title.text = "My Presentation Title"
subtitle.text = "Subtitle or Author Name"

# -------------------------------
# Slide 2: Content Slide
# -------------------------------
slide_layout = prs.slide_layouts[1]  # Title + Content layout
slide = prs.slides.add_slide(slide_layout)

title = slide.shapes.title
content = slide.placeholders[1]

title.text = "Agenda"

tf = content.text_frame
tf.clear()

points = [
    "Introduction",
    "Main Topic",
    "Conclusion"
]

for i, point in enumerate(points):
    if i == 0:
        tf.text = point
    else:
        p = tf.add_paragraph()
        p.text = point
        p.level = 1

# -------------------------------
# Slide 3: Add Image
# -------------------------------
slide_layout = prs.slide_layouts[5]  # Blank slide
slide = prs.slides.add_slide(slide_layout)

left = Inches(1)
top = Inches(1)
width = Inches(5)

slide.shapes.add_picture("image.png", left, top, width=width)

# -------------------------------
# Slide 4: Add Shape with Text
# -------------------------------
slide_layout = prs.slide_layouts[5]  # Blank slide
slide = prs.slides.add_slide(slide_layout)

left = Inches(2)
top = Inches(2)
width = Inches(4)
height = Inches(1.5)

shape = slide.shapes.add_shape(
    MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
    left, top, width, height
)

shape.fill.background()  # Optional: remove fill
shape.text = "Custom Shape Text"

# -------------------------------
# Save Presentation
# -------------------------------
prs.save("output_presentation.pptx")

print("Presentation created successfully!")