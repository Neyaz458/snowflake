def add_numbers(a, b):
    return a + b

result = add_numbers(3, 4)
print(f'3 + 4 = {result}')
