print('Counting to 3:')
for i in range(1, 4):
    print(i)
