def say_hello():
    return 'Hello from the zip file!'
