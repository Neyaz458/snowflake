name = 'Alice'
age = 25
